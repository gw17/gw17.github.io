#
#            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
#                    Version 2, December 2004
#
# Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>
#
# Everyone is permitted to copy and distribute verbatim or modified
# copies of this license document, and changing it is allowed as long
# as the name is changed.
#
#            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
#   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
#
#  0. You just DO WHAT THE FUCK YOU WANT TO.
"""Code to automatically modify the representation of several
syntactic constructions defined by the UD guidelines.

Dependencies:
- lxml (https://github.com/lxml/lxml)

"""

import os
import random
import json
import pickle

from lxml import etree
from warnings import warn
from itertools import tee
from collections import defaultdict
from copy import deepcopy
from operator import itemgetter

from import_corpora import read_conllx as read_conll, is_projective
from listener import SimpleListener


def pairwise(iterable):
    a, b = tee(iterable)
    next(b, None)
    return zip(a, b)


def dep2etree(words, fpos, cpos, dependencies, labels):
    """
    Create an ElementTree representation of a dependency from the structure used in our parser

    Be carefull: all padding *must* be removed
    """
    assert words[0] != "<start>", "Padding must be removed"

    elements = [etree.Element("node", idx=str(i), word=w, cpos=cp, fpos=fp)
                for i, (w, fp, cp) in enumerate(zip(words, fpos, cpos))]

    elements[-1].attrib["last"] = str(True)

    root = None
    for el, dep, label in zip(elements, dependencies, labels):
        if dep == len(elements):
            root = el
        else:
            head = elements[dep]
            head.append(el)
            el.set("label", label)

    tree = etree.ElementTree(root)
    return tree


def etree2dep(tree):
    """
    Extract the list of heads from a ElementTree representing a dependency tree.
    """

    nodes = list(tree.iterdescendants()) + [tree]

    heads = []
    root = None
    for node in sorted(nodes, key=lambda x: int(x.attrib["idx"])):
        if node.getparent() is None:
            head = 0
            root = node.attrib["idx"]
        else:
            head = int(node.getparent().attrib["idx"])

        heads.append(head)

    assert root is not None

    heads[int(root)] = len(heads)

    return heads


def etree2conll(tree):

    res = []
    template = "{idx}\t{word}\t_\t{cpos}\t{fpos}\t_\t{head}\t{label}\t_\t_"
    nodes = list(tree.iterdescendants()) + [tree]

    for node in sorted(nodes, key=lambda x: int(x.attrib["idx"])):
        attrib = dict(node.attrib)

        if node.getparent() is None:
            attrib["label"] = "root"
            head = 0
        else:
            head = int(node.getparent().attrib["idx"]) + 1

        attrib["idx"] = int(attrib["idx"]) + 1
        attrib["head"] = head
        res.append(template.format(**attrib))

    res = "\n".join(res)

    return res


class TreeTransformation:

    def __init__(self, selector, ignore_error=True):
        self.selector = selector
        self.n_apply = 0
        self.n_fail = 0
        self.ignore_error = ignore_error

    def apply(self, input_tree):
        output_trees = [(deepcopy(input_tree), 0)]

        for input_el in input_tree.xpath(self.selector):
            #print(input_el.attrib)
            self.n_apply += 1

            new_output = []
            for tree, n_changes in output_trees:
                new_tree = deepcopy(tree)
                old_el = new_tree.xpath("//node[@idx='{}']".format(input_el.attrib["idx"]))
                assert len(old_el) == 1, "missing node: {}".format(input_el.attrib["idx"])
                old_el = old_el[0]

                try:
                    new_el = self.transform(old_el)
                except Exception as e:
                    if not self.ignore_error:
                        raise e
                    self.n_fail += 1
                    continue

                parent = old_el.getparent()
                if parent is not None:
                    child_index = list(parent).index(old_el)
                    parent[child_index] = new_el
                else:
                    new_tree._setroot(new_el)

                new_output.append((deepcopy(new_tree), n_changes + 1))
                new_output.append((deepcopy(tree), n_changes))

            output_trees = new_output

        return output_trees


class ConjunctionTransform(TreeTransformation):

    def __init__(self, ignore_error=False):
        # select the head of the `cc` dependence
        # the `cc` dependence is used to attach the conjunction to its head
        super().__init__("//node[node[@label='cc']]", ignore_error)
        self.name = "conj"

    # XXX we are not transforming the labels
    def transform(self, el):
        # find the first conjonction -- other cc will be rattached to
        # the first cc
        conj = el.findall("./node[@label='cc']")
        assert conj is not None

        other_cc = conj[1:]
        conj = conj[0]

        # find other part of the conjonction (the Y in `X and
        # Y'). These parts have a label "conj". The X was the original
        # head.
        others = el.findall("./node[@label='conj']")
        assert others is not None

        # copy all children
        new_el = etree.Element("node", **el.attrib)
        new_el.extend(c for c in el if c not in others and c is not conj and el not in others and el not in other_cc and "last" not in c.attrib)

        conj.append(new_el)
        conj.extend(others)
        conj.extend(other_cc)
        conj.extend(c for c in el if "last" in c.attrib)
        
        return conj


class DetTransform(TreeTransformation):

    def __init__(self, ignore_error=True):
        super().__init__("//node[node[@label='det']]")
        self.name = "det"

    def transform(self, noun_node):
        position = lambda x: int(x.attrib["idx"])
        
        det_node = noun_node.find("./node[@label='det']")

        new_noun_node = etree.Element("node", **noun_node.attrib)

        det_node.append(new_noun_node)

        # XXX will not work: we are not serializing labels!!
        # det_node.attrib["label"] = noun_node.attrib["label"]
        # new_noun_node.attrib["label"] = "det"

        assert position(det_node) < position(noun_node)

        new_noun_node.extend(c for c in noun_node if c is not det_node and position(c) > position(det_node))
        det_node.append(new_noun_node)
        det_node.extend(c for c in noun_node if position(c) < position(det_node))

        return det_node

    
class CaseTransform(TreeTransformation):

    def __init__(self, ignore_error=True):
        # select all nodes that have a dependant labeled as "case"
        super().__init__(""".//node[node[@label='case' and @word!="'s"]]""", ignore_error)
        self.name = "case"

    def transform(self, i_node):

        j_node = i_node.find("./node[@label='case']")
        new_i_node = etree.Element("node", **i_node.attrib)

        if position(j_node) < position(i_node):
            new_i_node.extend(c for c in i_node if c is not j_node and position(c) > position(j_node))
            j_node.append(new_i_node)
            j_node.extend(c for c in i_node if position(c) < position(j_node))
        else:
            new_i_node.extend(c for c in i_node if c is not j_node and position(c) < position(j_node))
            j_node.append(new_i_node)
            j_node.extend(c for c in i_node if position(c) > position(j_node))

        return j_node


position = lambda x: int(x.attrib["idx"])


class CopuleTransform(TreeTransformation):

    def __init__(self, ignore_error=False):
        super().__init__("//node[node[@label='auxpass'] or node[@label='cop']]", ignore_error)
        self.name = "copule"

    def transform(self, el):
        NOUN_ATTRIB = {"det", "amod", "mwe", "name", "compound", "nummod",
                       "case", "nmod", "expl", "acl:relcl", "nmod:poss"}

        # select the dependant in the `cop` or `auxpass` relation
        aux = el.findall("./node[@label='auxpass']") + el.findall("./node[@label='cop']")
        if len(aux) != 1:
            # if there is a `cop` and `auxpass` (e.g. "X est appelé
            # Y"). To uniformize dependencies, we select the auxiliary as the verb
            aux = el.findall("./node[@label='auxpass']")
            assert len(aux) == 1
            
        aux = aux[0]

        new_aux = etree.Element("node", **aux.attrib)
        new_aux.attrib["label"] = "root"

        attr = etree.Element("node", **el.attrib)
        attr.attrib["label"] = "cop"
        
        if position(new_aux) < position(attr):
            attr.extend(c for c in el if c.attrib["label"] in NOUN_ATTRIB and position(c) > position(new_aux))

            new_aux.extend(c for c in el if c is not aux and c.attrib["label"] not in NOUN_ATTRIB or position(c) < position(new_aux))
            new_aux.append(attr)
            new_aux.extend(c for c in aux)
        else:
            raise Exception
            attr.extend(c for c in el if c.attrib["label"] in NOUN_ATTRIB and position(c) < position(new_aux))
            new_aux.append(attr)
            new_aux.extend(c for c in aux)
            new_aux.extend(c for c in el if position(c) > position(new_aux))

        return new_aux


class NameNameTransform(TreeTransformation):

    def __init__(self, ignore_error=False):
        super().__init__("//node[node[@label='name'] and count(./node[@label='name'])>1]", ignore_error)
        self.name = "noun"
        
    def transform(self, el):
        name_el = el.findall("./node[@label='name']")

        new_root = etree.Element("node", **el.attrib)
        new_root.extend(c for c in el if c not in name_el)
        new_root.append(name_el[0])

        for a, b in pairwise(name_el):
            a.append(b)

        return new_root

        
class MWETransform(TreeTransformation):

    def __init__(self, ignore_error=False):
        super().__init__("//node[node[@label='mwe'] and count(./node[@label='mwe'])>1]", ignore_error)
        self.name = "mwe"

    def transform(self, el):

        mwe_el = el.findall("./node[@label='mwe']")

        new_root = etree.Element("node", **el.attrib)
        new_root.extend(c for c in el if c not in mwe_el)
        new_root.append(mwe_el[0])

        for a, b in pairwise(mwe_el):
            a.append(b)

        return new_root


class MarkTransform(TreeTransformation):

    def __init__(self, ignore_error=False):
        super().__init__(".//node[node[@label='mark']]", ignore_error)
        self.name = "mark"

    def transform(self, i_node):
        position = lambda x: int(x.attrib["idx"])

        j_node = i_node.find("./node[@label='mark']")
        new_i_node = etree.Element("node", **i_node.attrib)

        if position(j_node) < position(i_node):
            new_i_node.extend(c for c in i_node if c is not j_node and position(c) > position(j_node))
            j_node.append(new_i_node)
            j_node.extend(c for c in i_node if position(c) < position(j_node))
        else:
            new_i_node.extend(c for c in i_node if c is not j_node and position(c) < position(j_node))
            j_node.append(new_i_node)
            j_node.extend(c for c in i_node if position(c) > position(j_node))

        return j_node


def dependencies_transform(corpus, transforms, listener):

    def filter_examples(corpus):
        """
        Remove examples that are too long & non projective sentences
        """

        for words, feat, heads, labels in corpus:

            if len(words) > 40:
                continue

            if not is_projective(heads, is_padded=False):
                warn("non-projective sentence in the input corpus --- ignore")
                continue

            yield words, feat, heads, labels

    def apply_transforms(words, feat, heads, labels):

        references = {}      
        references[0, ("orig",), (0,)] = heads

        for transform in transforms:

            new_references = {}
            for (_, transfo_name, n_prev_changes), heads in references.items():
                input_tree = dep2etree(words, feat["fpos"], feat["cpos"], heads, labels)

                try:
                    output_trees = transform.apply(input_tree)
                except Exception as e:
                    print(e)
                    print(words)
                    print(heads)
                    print(labels)
                    continue
                    sys.exit(1)
                    
                for new_tree, n_changes in output_trees:
                    new_heads = etree2dep(new_tree.getroot())
                    if not is_projective(new_heads, is_padded=False):
                        # print(words)
                        # print(heads)
                        # print(labels)
                        # if len(words) < 10:
                        #     sys.exit(1)
                        warn("Transform non projective")
                        break

                    new_references[len(new_references), transfo_name + (transform.name,), n_prev_changes + (n_changes,)] = new_heads

            references = new_references

        return references

    examples = []
    n_total = 0
    n_transform = 0
    for words, feat, heads, labels in filter_examples(corpus):
        n_total += 1
        references = apply_transforms(words, feat, heads, labels)

        if not references:
            continue

        all_counts = (r[-1] for r in references)
        max_counts = tuple(max(m) for m in zip(*all_counts))

        new_references = {}
        for r in references:
            if all(rr == 0 for rr in r[-1]):
                new_r = (r[0], r[1], "min_changes")
            elif r[-1] == max_counts:
                new_r = (r[0], r[1], "max_changes")
            else:
                new_r = r

            new_references[new_r] = references[r]

            # ensure that there is always one entry whose key is `max_changes`
            # and one whose key is `min_changes`
            if len(references) == 1:
                new_r = (r[0], r[1], "max_changes")
                new_references[new_r] = references[r]

        n_transform += 1
        examples.append((words, feat, new_references, labels, max_counts))

    print("Transformed {:.2%} sentence".format(n_transform / n_total))
        
    return examples


transforms = {"conjunction_transform": ConjunctionTransform,
              "case_transform": CaseTransform,
              "name_transform": NameNameTransform,
              "mwe_transform": MWETransform,
              "copule_transform": CopuleTransform,
              "det_transform": DetTransform,
              "mark_transform": MarkTransform}


if __name__ == "__main__":

    import argparse
    parser = argparse.ArgumentParser(description="Transform dependency structure")

    parser.add_argument("--input", required=True, type=argparse.FileType("r"), help="input treebank (in conllu format)")
    parser.add_argument("--output", required=True, type=argparse.FileType("wb"))
    parser.add_argument("--ignore_error", default=False, action="store_true")
    parser.add_argument("--transform", required=True, nargs="+", choices=list(transforms.keys()))
    
    args = parser.parse_args()

    data = dependencies_transform(read_conll(args.input, without_padding=True),
                                  [transforms[t](ignore_error=True) for t in args.transform],
                                  SimpleListener())
    pickle.dump(data, args.output)
