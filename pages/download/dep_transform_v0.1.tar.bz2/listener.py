#
#            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
#                    Version 2, December 2004
#
# Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>
#
# Everyone is permitted to copy and distribute verbatim or modified
# copies of this license document, and changing it is allowed as long
# as the name is changed.
#
#            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
#   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
#
#  0. You just DO WHAT THE FUCK YOU WANT TO.

try:
    from termcolor import colored
except ImportError:
    colored = lambda x, y: x

try:
    import sqlite3 as lite
except ImportError:
    pass
import json


class SimpleListener:

    def __init__(self, name=None, null=False):
        self.null = null
        self.name = name
        
    def iter(self, what):
        if self.null:
            return what

        try:
            import frogress
            return frogress.bar(what)
        except ImportError:
            return what

    def msg(self, what, color=None):

        if self.null:
            return

        if self.name is not None:
            what = "[{}] {}".format(self.name, what)

        if color is not None:
            what = colored(what, color)

        print(what)

    def __enter__(self):
        self.msg("start")

    def __exit__(self, exception_type, exception_value, exception_traceback):
        if exception_type is None:
            self.msg("done", "green")
        else:
            self.msg("fail", "red")
        

class SqlListener:

    def __init__(self, name, db_filename):
        self.con = lite.connect(db_filename)
        self.task_name = name
        
        with self.con:
            cur = self.con.cursor()
            cur.execute("INSERT INTO Monitoring VALUES('{}', 'PENDING', '[]', 0)".format(self.task_name))

    @staticmethod
    def create_db(db_filename):

        con = lite.connect(db_filename)

        with con:
            cur = con.cursor()
            cur.execute("DROP TABLE IF EXISTS Monitoring")
            cur.execute("CREATE TABLE Monitoring(task TEXT, status TEXT, messages TEXT, progress INT)")

    def __enter__(self):
        with self.con:
            cur = self.con.cursor()
            cur.execute("UPDATE Monitoring SET status = 'RUNNING' where task = '{}'".format(self.task_name))

    def __exit__(self, exception_type, exception_value, exception_traceback):
        if exception_type is None:
            with self.con:
                cur = self.con.cursor()
                cur.execute("UPDATE Monitoring SET status = 'DONE' where task = '{}'".format(self.task_name))
        else:
            with self.con:
                cur = self.con.cursor()
                cur.execute("UPDATE Monitoring SET status = 'FAIL' where task = '{}'".format(self.task_name))

    # XXX do not handle the case in which data has no length
    def iter(self, data):

        old_percentage = 0
        for i, d in enumerate(data):
            yield d

            if int(i / len(data) * 100) != old_percentage:
                old_percentage = int(i / len(data) * 100)
                with self.con:
                    cur = self.con.cursor()
                    cur.execute("UPDATE Monitoring SET progress = {} WHERE task = '{}'".format(old_percentage, self.task_name))

    def msg(self, what, color=None):
       with self.con:
           cur = self.con.cursor()
           cur.execute("SELECT messages FROM Monitoring WHERE task = '{}'".format(self.task_name))

           res = cur.fetchall()

           assert len(res) == 1, res
           messages = json.loads(res[0][0])

           messages.append(what)

           cur.execute("UPDATE Monitoring SET messages = '{}' where task = '{}'".format(json.dumps(messages),
                                                                                        self.task_name))
           
if __name__ == "__main__":
    create_db("test.db")

    s = SqlListener("test.db", "pouet")
    s.start()
    s.msg("pouet")
    s.iter(list(range(100)))
    s.end()
