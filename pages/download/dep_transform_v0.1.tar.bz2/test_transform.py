#
#            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
#                    Version 2, December 2004
#
# Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>
#
# Everyone is permitted to copy and distribute verbatim or modified
# copies of this license document, and changing it is allowed as long
# as the name is changed.
#
#            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
#   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
#
#  0. You just DO WHAT THE FUCK YOU WANT TO.

import pytest

from lxml import etree
from io import StringIO
from unittest.mock import MagicMock

from dep_transform import dep2etree, etree2conll, ConjunctionTransform, CaseTransform, MarkTransform, etree2dep, CopuleTransform, MWETransform, dependencies_transform, NameNameTransform, DetTransform
from import_corpora import read_conllx as read_conll
from import_corpora import is_projective


def test_generating_etree():
    """
    Generate an ElementTree representation of the dependency tree
    """
    
    words = "Je suis déchirée .".split()
    pos = "PRON VERB ADJ PUNCT".split()
    dep = [2, 2, 4, 2]
    labels = "nsubj cop root punct".split()

    res = dep2etree(words, pos, pos, dep, labels)

    assert etree.tostring(res, encoding=str) == """<node cpos="ADJ" fpos="ADJ" idx="2" word="déchirée"><node cpos="PRON" fpos="PRON" idx="0" word="Je" label="nsubj"/><node cpos="VERB" fpos="VERB" idx="1" word="suis" label="cop"/><node cpos="PUNCT" fpos="PUNCT" idx="3" word="." last="True" label="punct"/></node>"""


def test_generate_conll():
    """
    Generate a CONLL representation of an ElementTree
    """

    sentence = """<node cpos="ADJ" fpos="ADJ" idx="2" word="déchirée"><node cpos="PRON" fpos="PRON" idx="0" word="Je" label="nsubj"/><node cpos="VERB" fpos="VERB" idx="1" word="suis" label="cop"/><node cpos="PUNCT" fpos="PUNCT" idx="3" word="." label="punct"/></node>"""
    sentence = etree.fromstring(sentence)

    expected_res = """1 Je _ PRON PRON _ 3 nsubj _ _
2 suis _ VERB VERB _ 3 cop _ _
3 déchirée _ ADJ ADJ _ 0 root _ _
4 . _ PUNCT PUNCT _ 3 punct _ _"""
    
    res = etree2conll(sentence).replace("\t", " ")
    assert res == expected_res




def test_etree2dep():

    conll_input = """1       Toutefois       toutefois       ADV     _       _       5       advmod  _       _
2       ,       ,       PUNCT   _       _       5       punct   _       _
3       les     le      DET     _       Definite=Def|Gender=Fem|Number=Plur     4       det     _       _
4       filles  fille   NOUN    _       Gender=Fem|Number=Plur  5       nsubj   _       _
5       adorent adorer  VERB    _       Mood=Ind|Number=Plur|Person=3|Tense=Pres|VerbForm=Fin   0       root    _       _
6       les     le      DET     _       Definite=Def|Gender=Masc|Number=Plur    7       det     _       _
7       desserts        dessert NOUN    _       Gender=Masc|Number=Plur 5       dobj    _       _
8       .       .       PUNCT   _       _       5       punct   _       _
"""

    from import_corpora import read_conllx
    from io import StringIO

    r = StringIO(conll_input)
    words, feat, heads, labels = next(read_conllx(r, without_padding=True))

    tree = dep2etree(words, feat["cpos"], feat["cpos"], heads, labels)
    
    assert etree2dep(tree.getroot()) == heads


# XXX Transformation correct par rapport au code, mais dont la sémantique
# est plus que douteuse
@pytest.mark.copule
def test_copule():
    words = ['Le', 'cours', 'de', 'dessin', 'est', 'il', 'pour', 'les', 'débutants', '?']
    heads = [1, 8, 3, 1, 8, 8, 8, 8, 10, 8]
    labels = ['det', 'nsubj', 'case', 'nmod', 'cop', 'expl', 'case', 'det', 'root', 'punct']
    cpos = ['DET', 'NOUN', 'ADP', 'NOUN', 'VERB', 'PRON', 'ADP', 'DET', 'NOUN', 'PUNCT']
    
    input_tree = dep2etree(words, cpos, cpos, heads, labels)

    transform = CopuleTransform(ignore_error=False)
    trees = transform.apply(input_tree)

    expected_res = {((1, 8, 3, 1, 8, 8, 8, 8, 10, 8), 0), ((1, 4, 3, 1, 10, 8, 8, 8, 4, 4), 1)}
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.copule
def test_copule_passif_root():
    """
    Transformation of copule-like construction: the root of the
    sentence is an adjective used in a passive construct. Change it so
    it becomes the auxiliary.
    """
    words = ['Le', 'château', 'est', 'ensuite', 'vendu', 'plusieurs', 'fois', ';']
    heads = [1, 4, 4, 4, 8, 6, 4, 4]
    labels = ['det', 'nsubjpass', 'auxpass', 'advmod', 'root', 'det', 'nmod', 'punct']
    cpos = ['DET', 'NOUN', 'AUX', 'ADV', 'VERB', 'DET', 'NOUN', 'PUNCT']

    input_tree = dep2etree(words, cpos, cpos, heads, labels)

    copule_transform = CopuleTransform(ignore_error=False)
    trees = copule_transform.apply(input_tree)
    
    expected_res = {((1, 2, 8, 4, 2, 6, 4, 2), 1), ((1, 4, 4, 4, 8, 6, 4, 4), 0)}
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.copule
def test_copule_non_root():

    words = ['Ismene', 'entre', 'et', 'annonce', 'que', "c'", 'est', 'Farnace', 'qui', 'a', 'mis', 'le', 'feu', 'à', 'la', 'flotte', 'romaine', '.']
    heads = [1, 18, 1, 1, 7, 7, 7, 3, 10, 10, 7, 12, 10, 15, 15, 10, 15, 1]
    labels = ['nsubj', 'root', 'cc', 'conj', 'mark', 'nsubj', 'cop', 'ccomp', 'nsubj', 'aux', 'acl:relcl', 'det', 'dobj', 'case', 'det', 'nmod', 'amod', 'punct']
    cpos = ['PROPN', 'VERB', 'CONJ', 'NOUN', 'SCONJ', 'PRON', 'VERB', 'PROPN', 'PRON', 'AUX', 'VERB', 'DET', 'NOUN', 'ADP', 'DET', 'NOUN', 'ADJ', 'PUNCT']
    
    tree = dep2etree(words, cpos, cpos, heads, labels)

    copule_transform = CopuleTransform(ignore_error=False)
    trees = copule_transform.apply(tree)

    expected_res = {((1, 18, 1, 1, 7, 7, 7, 3, 10, 10, 7, 12, 10, 15, 15, 10, 15, 1), 0),
                    ((1, 18, 1, 1, 6, 6, 3, 6, 10, 10, 7, 12, 10, 15, 15, 10, 15, 1), 1)}
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


def test_copule_error():

    #words = ['Но', 'той', 'е', 'против', 'другите', 'да', 'се', 'разпространяват', '.']
    words = "abcdefghi"
    heads = [2, 2, 9, 7, 7, 7, 7, 2, 2]
    labels = ['cc', 'nsubj', 'root', 'case', 'nsubj', 'aux', 'expl', 'cop', 'punct']

    tree = dep2etree(words, words, words, heads, labels)

    transform = CopuleTransform(ignore_error=False)
    trees = transform.apply(tree)

    expected_res = {((7, 7, 7, 7, 7, 7, 7, 9, 7), 1),
                    (tuple(heads), 0)}

    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.copule
def test_simple_copule_transform():
    words = ['Le', 'président', 'de', 'le', 'conseil', 'est', 'David', 'A.', 'Galloway', '.']
    heads = [1, 6, 4, 4, 1, 6, 10, 6, 6, 6]
    labels = ['det', 'nsubj', 'case', 'det', 'nmod', 'cop', 'root', 'name', 'name', 'punct']


    expected_res = {((1, 6, 4, 4, 1, 6, 10, 6, 6, 6), 0), ((1, 5, 4, 4, 1, 10, 5, 6, 6, 5), 1)}
    
    input_tree = dep2etree(words, words, words, heads, labels)

    transform = CopuleTransform(ignore_error=False)
    trees = transform.apply(input_tree)
    
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.copule
def test_new_copule():

    words = ['La', 'commune', 'est', 'un', 'chef-lieu', 'de', 'canton', '.',]
    heads = [1, 4, 4, 4, 8, 6, 4, 4]
    labels = ['det', 'nsubj', 'cop', 'det', 'root', 'case', 'nmod', 'punct']

    input_tree = dep2etree(words, words, words, heads, labels)

    transform = CopuleTransform(ignore_error=False)
    trees = transform.apply(input_tree)

    expected_res = {((1, 2, 8, 4, 2, 6, 4, 2), 1),
                    ((1, 4, 4, 4, 8, 6, 4, 4), 0)}

    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.copule
def test_copules_deux_aux():

    words = ['Ses', 'habitants', 'sont', 'appelés', 'les', 'Paydrets', 'et', 'les', 'Paydrètes', ';']
    heads = [1, 5, 5, 5, 5, 10, 5, 8, 5, 5]
    labels = ['nmod:poss', 'nsubjpass', 'auxpass', 'cop', 'det', 'root', 'cc', 'det', 'conj', 'punct']

    input_tree = dep2etree(words, words, words, heads, labels)

    transform = CopuleTransform(ignore_error=False)
    trees = transform.apply(input_tree)

    expected_res = {((1, 5, 5, 5, 5, 10, 5, 8, 5, 5), 0), ((1, 2, 10, 2, 5, 2, 2, 8, 2, 2), 1)}

    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res
    

@pytest.mark.copule
def test_copule_non_projective():

    words = ['Génial', ',', 'et', 'en', 'plus', "c'", 'est', 'rapide', '.']
    heads = [9, 0, 0, 7, 3, 7, 7, 0, 0]
    labels = ['root', 'punct', 'cc', 'advmod', 'mwe', 'nsubj', 'cop', 'conj', 'punct']

    input_tree = dep2etree(words, words, words, heads, labels)

    transform = CopuleTransform(ignore_error=False)
    trees = transform.apply(input_tree)

    expected_res = {((9, 0, 0, 7, 3, 7, 7, 0, 0), 0), ((9, 0, 0, 6, 3, 6, 0, 6, 0), 1)}
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res

    # ---------------
    
    words = ['Bon', ',', 'allez', ',', 'je', 'suis', 'connue', 'pour', 'être', 'pinailleuse', 'et', 'difficile', 'alors']
    heads = [6, 6, 6, 6, 6, 6, 13, 9, 9, 6, 9, 9, 9]
    labels = ['discourse', 'punct', 'parataxis', 'punct', 'nsubjpass', 'aux', 'root', 'case', 'cop', 'amod', 'cc', 'conj', 'advmod']

    input_tree = dep2etree(words, words, words, heads, labels)

    transform = CopuleTransform(ignore_error=False)
    trees = transform.apply(input_tree)

    expected_res = {((6, 6, 6, 6, 6, 6, 13, 8, 6, 8, 8, 8, 8), 1), ((6, 6, 6, 6, 6, 6, 13, 9, 9, 6, 9, 9, 9), 0)}
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res

    # ----------------
    
    words = ['Ici', "c'", 'est', 'très', 'professionnelle', '.']
    heads = [4, 4, 4, 4, 6, 4]
    labels = ['advmod', 'nsubj', 'cop', 'advmod', 'root', 'punct']

    input_tree = dep2etree(words, words, words, heads, labels)

    transform = CopuleTransform(ignore_error=False)
    trees = transform.apply(input_tree)

    expected_res = {((4, 4, 4, 4, 6, 4), 0), ((2, 2, 6, 2, 2, 2), 1)}
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res

    # --------------

    words = ['Il', 'est', 'développé', 'et', 'édité', 'par', 'Namco', '.']
    heads = [2, 2, 8, 2, 2, 6, 2, 2]
    labels = ['nsubjpass', 'auxpass', 'root', 'cc', 'conj', 'case', 'nmod', 'punct']
    assert False
    
    
def test_cli_one_transform():

    input_fh = StringIO("""# sentid: fr-ud-dev_00001
# sentence-text: Aviator, un film sur la vie de Hughes.
1	Aviator	Aviator	PROPN	_	_	0	root	_	_
2	,	,	PUNCT	_	_	1	punct	_	_
3	un	un	DET	_	Definite=Ind|Gender=Masc|Number=Sing|PronType=Dem	4	det	_	_
4	film	film	NOUN	_	Gender=Masc|Number=Sing	1	appos	_	_
5	sur	sur	ADP	_	_	7	case	_	_
6	la	le	DET	_	Definite=Def|Gender=Fem|Number=Sing	7	det	_	_
7	vie	vie	NOUN	_	Gender=Fem|Number=Sing	4	nmod	_	_
8	de	de	ADP	_	_	9	case	_	_
9	Hughes	Hughes	PROPN	_	_	7	nmod	_	_
10	.	.	PUNCT	_	_	1	punct	_	_

# sentid: fr-ud-dev_00002
# sentence-text: Les études durent six ans mais leur contenu diffère donc selon les Facultés.
1	Les	le	DET	_	Definite=Def|Gender=Fem|Number=Plur	2	det	_	_
2	études	étude	NOUN	_	Gender=Fem|Number=Plur	3	nsubj	_	_
3	durent	durer	VERB	_	Mood=Ind|Number=Plur|Person=3|Tense=Pres|VerbForm=Fin	0	root	_	_
4	six	six	NUM	_	_	5	nummod	_	_
5	ans	an	NOUN	_	Gender=Masc|Number=Plur	3	dobj	_	_
6	mais	mais	CONJ	_	_	3	cc	_	_
7	leur	son	DET	_	Gender=Masc|Number=Sing	8	nmod:poss	_	_
8	contenu	contenu	NOUN	_	Gender=Masc|Number=Sing	9	nsubj	_	_
9	diffère	différer	VERB	_	Mood=Ind|Number=Sing|Person=3|Tense=Pres|VerbForm=Fin	3	conj	_	_
10	donc	donc	ADV	_	_	9	advmod	_	_
11	selon	selon	ADP	_	_	13	case	_	_
12	les	le	DET	_	Definite=Def|Number=Plur	13	det	_	_
13	Facultés	Facultés	PROPN	_	_	9	nmod	_	_
14	.	.	PUNCT	_	_	3	punct	_	_
""")

    res = dependencies_transform(read_conll(input_fh, without_padding=True), [ConjunctionTransform(True)], MagicMock())

    expected_res = [(['Aviator', ',', 'un', 'film', 'sur', 'la', 'vie', 'de', 'Hughes', '.'], 
                     {'morpho': [{}, {}, {'Gender': 'Masc', 'PronType': 'Dem', 'Definite': 'Ind', 'Number': 'Sing'}, {'Gender': 'Masc', 'Number': 'Sing'}, {}, {'Gender': 'Fem', 'OCDefinite': 'Def', 'Number': 'Sing'}, {'Gender': 'Fem', 'Number': 'Sing'}, {}, {}, {}], 'lemma': ['Aviator', ',', 'un', 'film', 'sur', 'le', 'vie', 'de', 'Hughes', '.'], 'cpos': ['PROPN', 'PUNCT', 'DET', 'NOUN', 'ADP', 'DET', 'NOUN', 'ADP', 'PROPN', 'PUNCT'], 'fpos': ['_', '_', '_', '_', '_', '_', '_', '_', '_', '_']}, 
                     {(0, ('orig', 'conj'), "min_changes"): [10, 0, 3, 0, 6, 6, 3, 8, 6, 0],
                      (0, ('orig', 'conj'), "max_changes"): [10, 0, 3, 0, 6, 6, 3, 8, 6, 0]}, 
                     ['root', 'punct', 'det', 'appos', 'case', 'det', 'nmod', 'case', 'nmod', 'punct']), 
                (['Les', 'études', 'durent', 'six', 'ans', 'mais', 'leur', 'contenu', 'diffère', 'donc', 'selon', 'les', 'Facultés', '.'], 
                 {'morpho': [{'Gender': 'Fem', 'Definite': 'Def', 'Number': 'Plur'}, {'Gender': 'Fem', 'Number': 'Plur'}, {'Person': '3', 'Mood': 'Ind', 'VerbForm': 'Fin', 'Tense': 'Pres', 'Number': 'Plur'}, {}, {'Gender': 'Masc', 'Number': 'Plur'}, {}, {'Gender': 'Masc', 'Number': 'Sing'}, {'Gender': 'Masc', 'Number': 'Sing'}, {'Person': '3', 'Mood': 'Ind', 'VerbForm': 'Fin', 'Tense': 'Pres', 'Number': 'Sing'}, {}, {}, {'Definite': 'Def', 'Number': 'Plur'}, {}, {}], 'lemma': ['le', 'étude', 'durer', 'six', 'an', 'mais', 'son', 'contenu', 'différer', 'donc', 'selon', 'le', 'Facultés', '.'], 'cpos': ['DET', 'NOUN', 'VERB', 'NUM', 'NOUN', 'CONJ', 'DET', 'NOUN', 'VERB', 'ADV', 'ADP', 'DET', 'PROPN', 'PUNCT'], 'fpos': ['_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_']}, 
                 {(1, ('orig', 'conj'), "min_changes"): [1, 2, 14, 4, 2, 2, 7, 8, 2, 8, 12, 12, 8, 2], 
                  (0, ('orig', 'conj'), "max_changes"): [1, 2, 5, 4, 2, 14, 7, 8, 5, 8, 12, 12, 8, 5]}, 
                 ['det', 'nsubj', 'root', 'nummod', 'dobj', 'cc', 'nmod:poss', 'nsubj', 'conj', 'advmod', 'case', 'det', 'nmod', 'punct'])]

    expected_res = [{(k[1], k[2], tuple(v)) for k, v in e[-2].items()} for e in expected_res]
    res = [{(k[1], k[2], tuple(v)) for k, v in r[-3].items()} for r in res]

    assert res == expected_res


def test_cli_several_transform():

    input_content = StringIO("""#
1	Il	le	DET	_	Definite=Def|Gender=Fem|Number=Plur	2	subj	_	_
2	faut	le	DET	_	Definite=Def|Gender=Fem|Number=Plur	0	root	_	_
3	à	le	DET	_	Definite=Def|Gender=Fem|Number=Plur	4	case	_	_
4	boire	le	DET	_	Definite=Def|Gender=Fem|Number=Plur	2	dep	_	_
5	et	le	DET	_	Definite=Def|Gender=Fem|Number=Plur	4	cc	_	_
6	à	le	DET	_	Definite=Def|Gender=Fem|Number=Plur	7	case	_	_
7	manger	le	DET	_	Definite=Def|Gender=Fem|Number=Plur	5	conj	_	_
""")

    res = dependencies_transform(read_conll(input_content, without_padding=True), [ConjunctionTransform(True), CaseTransform(True)], MagicMock())

    expected_res = [(['Il', 'faut', 'à', 'boire', 'et', 'à', 'manger'],
                     {'cpos': ['DET', 'DET', 'DET', 'DET', 'DET', 'DET', 'DET'],
                      'fpos': ['_', '_', '_', '_', '_', '_', '_'],
                      'lemma': ['le', 'le', 'le', 'le', 'le', 'le', 'le'],
                      'morpho': [{'Definite': 'Def', 'Gender': 'Fem', 'Number': 'Plur'},
                                 {'Definite': 'Def', 'Gender': 'Fem', 'Number': 'Plur'},
                                 {'Definite': 'Def', 'Gender': 'Fem', 'Number': 'Plur'},
                                 {'Definite': 'Def', 'Gender': 'Fem', 'Number': 'Plur'},
                                 {'Definite': 'Def', 'Gender': 'Fem', 'Number': 'Plur'},
                                 {'Definite': 'Def', 'Gender': 'Fem', 'Number': 'Plur'},
                                 {'Definite': 'Def', 'Gender': 'Fem', 'Number': 'Plur'}]},
                     {(0, ('orig', 'conj', 'case'), (0, 0, 2)): [1, 7, 1, 2, 3, 4, 5],
                      (1, ('orig', 'conj', 'case'), (0, 0, 1)): [1, 7, 1, 2, 3, 6, 4],
                      (2, ('orig', 'conj', 'case'), (0, 0, 1)): [1, 7, 3, 1, 3, 4, 5],
                      (3, ('orig', 'conj', 'case'), "min_changes"): [1, 7, 3, 1, 3, 6, 4],
                      (4, ('orig', 'conj', 'case'), "max_changes"): [1, 7, 4, 2, 1, 4, 5],
                      (5, ('orig', 'conj', 'case'), (0, 1, 1)): [1, 7, 4, 2, 1, 6, 4],
                      (6, ('orig', 'conj', 'case'), (0, 1, 1)): [1, 7, 3, 4, 1, 4, 5],
                      (7, ('orig', 'conj', 'case'), (0, 1, 0)): [1, 7, 3, 4, 1, 6, 4]},
                     ['subj', 'root', 'case', 'dep', 'cc', 'case', 'conj'],
                     None)]
    
    expected_res = [{(k[1], k[2], tuple(v)) for k, v in e[-3].items()} for e in expected_res]
    res = [{(k[1], k[2], tuple(v)) for k, v in r[-3].items()} for r in res]

    assert res == expected_res



# =============
# Conjunctions
# =============

@pytest.mark.conj
def test_simple_conj():
    conjunction_transform = ConjunctionTransform(ignore_error=False)

    words = "what was found and fought".split()
    heads = [5, 2, 0, 2, 2]
    labels = "root auxpass acl cc conj".split()

    expected_res = {(tuple(heads), 0),
                    ((5, 2, 3, 0, 3), 1)}

    input_tree = dep2etree(words, words, words, heads, labels)
    trees = conjunction_transform.apply(input_tree)

    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.conj
def test_nonprojective_conj():
    words = ["L'", 'analyste', 'ou', 'utilisateur', 'avancé', 'appréciera', 'Coheris', 'Liberty', 'Studio', '.']
    heads = [1, 5, 1, 1, 1, 10, 5, 6, 6, 5]
    labels = ['det', 'nsubj', 'cc', 'conj', 'amod', 'root', 'dobj', 'name', 'name', 'punct']
    cpos = ['DET', 'NOUN', 'CONJ', 'NOUN', 'ADJ', 'VERB', 'PROPN', 'PROPN', 'PROPN', 'PUNCT']
    cpos = ['DET', 'NOUN', 'CONJ', 'NOUN', 'ADJ', 'VERB', 'PROPN', 'PROPN', 'PROPN', 'PUNCT']
    
    input_tree = dep2etree(words, cpos, cpos, heads, labels)

    conjunction_transform = ConjunctionTransform(ignore_error=False)
    trees = conjunction_transform.apply(input_tree)

    expected_res = {(tuple(heads), 0),
                    ((1, 2, 5, 2, 1, 10, 5, 6, 6, 5), 1)}
    
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.conj
def test_several_conj_several_words():
    """
    Transform a conjunction with several words
    """
    
    words = ["C'", 'est', 'un', 'gecko', 'insectivore', ',', 'nocturne', 'et', 'terrestre', '.']
    heads = [3, 3, 3, 10, 3, 4, 4, 4, 4, 3]
    labels = ['nsubj', 'cop', 'det', 'root', 'amod', 'punct', 'conj', 'cc', 'conj', 'punct']
    cpos = ['PRON', 'VERB', 'DET', 'NOUN', 'ADJ', 'PUNCT', 'ADJ', 'CONJ', 'ADJ', 'PUNCT']

    input_tree = dep2etree(words, cpos, cpos, heads, labels)

    conjunction_transform = ConjunctionTransform(ignore_error=False)
    trees = conjunction_transform.apply(input_tree)
    
    expected_res = {((3, 3, 3, 10, 7, 4, 7, 3, 7, 3), 1),
                    (tuple(heads), 0)}

    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.conj
def test_no_conj():

    words = ['Elle', 'était', 'censée', 'diminuer', 'voire', 'ôter', 'toute', 'ardeur', 'de', 'luxure', '.']
    heads = [2, 2, 11, 2, 3, 3, 7, 3, 9, 7, 2]
    labels = ['nsubj', 'aux', 'root', 'xcomp', 'cc', 'conj', 'det', 'dobj', 'case', 'nmod', 'punct']
    cpos = ['PRON', 'AUX', 'ADJ', 'VERB', 'ADV', 'VERB', 'DET', 'NOUN', 'ADP', 'NOUN', 'PUNCT']
    
    tree = dep2etree(words, cpos, cpos, heads, labels)

    conjunction_transform = ConjunctionTransform(ignore_error=False)
    trees = conjunction_transform.apply(tree)

    expected_res = {((2, 2, 11, 4, 2, 4, 7, 3, 9, 7, 2), 1),
                    (tuple(heads), 0)}

    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.conj
def test_several_cc():
    """
    Conjunction in which there are two cc (i.e. two "words" used to make the conjunction)
    """
    
    words = ['Il', 'est', 'le', 'premier', 'musicien', 'à', 'chanter', 'tant', 'en', 'français', "qu'", 'en', 'algonquin', '.']
    heads = [4, 4, 4, 4, 14, 6, 4, 9, 9, 6, 9, 12, 9, 4]
    labels = ['nsubj', 'cop', 'det', 'amod', 'root', 'mark', 'acl', 'cc', 'case', 'nmod', 'cc', 'case', 'conj', 'punct']
    cpos = ['PRON', 'VERB', 'DET', 'ADJ', 'NOUN', 'ADP', 'VERB', 'ADV', 'ADP', 'NOUN', 'SCONJ', 'ADP', 'NOUN', 'PUNCT']

    input_tree = dep2etree(words, cpos, cpos, heads, labels)

    conjunction_transform = ConjunctionTransform(ignore_error=False)
    trees = conjunction_transform.apply(input_tree)

    expected_res = {(tuple(heads), 0),
                    ((4, 4, 4, 4, 14, 6, 4, 6, 9, 7, 7, 12, 7, 4), 1)}
    
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.conj
def test_simple_and():
    """
    Simplest conjunction transformation: conjunction of two words
    """
    conjunction_transform = ConjunctionTransform(ignore_error=False)

    words = "religieux et symboliste".split()
    heads = [3, 0, 0]
    labels = "root cc conj".split()
    tree = dep2etree(words, words, words, heads, labels)

    expected_res = {(tuple(heads), 0),
                    ((1, 3, 1), 1)}

    trees = conjunction_transform.apply(tree)
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.conj
def test_root_transform():
    """
    Test conjunction transform when the conjunction becomes the ROOT
    """
    conjunction_transform = ConjunctionTransform(ignore_error=False)
    
    words = ['Mais', ',', 'le', 'SMIC', "n'", 'est', 'pas', 'un', 'outil', 'de', 'référence', '.']
    heads = [8, 8, 3, 8, 8, 8, 8, 8, 12, 10, 8, 8]
    labels = ['cc', 'punct', 'det', 'nsubj', 'neg', 'cop', 'neg', 'det', 'root', 'case', 'nmod', 'punct']

    tree = dep2etree(words, words, words, heads, labels)

    trees = conjunction_transform.apply(tree)

    expected_res = {(tuple(heads), 0),
                    ((12, 8, 3, 8, 8, 8, 8, 8, 0, 10, 8, 0), 1)}

    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.conj
def test_conj_non_proj():
    """
    Test conjunction transform when we have to re-attach the final
    punctuation (so thatthe tree does not become non-projective).
    """
    words = ['Les', 'études', 'durent', 'six', 'ans', 'mais', 'leur', 'contenu', 'diffère', 'donc', 'selon', 'les', 'Facultés', '.']
    heads = [1, 2, 14, 4, 2, 2, 7, 8, 2, 8, 12, 12, 8, 2]
    labels = "det nsubj root nummod dobj cc nmod:poss nsubj conj advmod case det nmod punct".split()

    conjunction_transform = ConjunctionTransform(ignore_error=False)

    tree = dep2etree(words, words, words, heads, labels)

    trees = conjunction_transform.apply(tree)

    # print(etree2str(tree.getroot()))    
    # print({(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees})

    expected_res = {(tuple(heads), 0),
                    ((1, 2, 5, 4, 2, 14, 7, 8, 5, 8, 12, 12, 8, 5), 1)}
    
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res
    
# =============
# MWETransform
# =============

@pytest.mark.mwe
def test_mwe_several():

    words = ["C'", 'est', 'un', 'RAS', 'LE', 'BOL', 'général', '!']
    heads = [3, 3, 3, 8, 3, 3, 3, 3]
    labels = ['nsubj', 'cop', 'det', 'root', 'mwe', 'mwe', 'amod', 'punct']
    
    input_tree = dep2etree(words, words, words, heads, labels)

    transform = MWETransform(ignore_error=False)
    trees = transform.apply(input_tree)

    expected_res = {(tuple(heads), 0),
                    ((3, 3, 3, 8, 3, 4, 3, 3), 1)}
    
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res
    

@pytest.mark.mwe
def test_mwe_single():
    """
    MWE transform when the MWE is made of two words
    """

    words = ['Cela', 'représente', 'plus', 'de', '400_000', 'personnes', '.']
    heads = [1, 7, 4, 2, 5, 1, 1]
    labels = ['nsubj', 'root', 'advmod', 'mwe', 'nummod', 'dobj', 'punct']
    
    tree = dep2etree(words, words, words, heads, labels)

    old_dep = [t for t in etree2dep(tree.getroot())]
    
    transform = MWETransform(ignore_error=False)
    trees = transform.apply(tree)

    expected_res = {(tuple(heads), 0)}
    
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


# ==============
# MarkTransform
# ==============

@pytest.mark.mark
def test_mark_before():

    mark_transform = MarkTransform(ignore_error=False)
    
    words = "ABCD"
    heads = [4, 3, 3, 0]
    labels = ["a", "b", "mark", "c"]
    cpos = "ABCD"

    input_tree = dep2etree(words, cpos, cpos, heads, labels)

    expected_res = {(tuple(heads), 0),
                    ((4, 2, 0, 2), 1)}
    
    trees = mark_transform.apply(input_tree)
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.mark
def test_mark_error():
    """
    Mark transform
    """

    mark_transform = MarkTransform(ignore_error=False)

    words = ['Pas', 'crier', 'avant', "d'", 'avoir', 'mal', '.']
    heads = [1, 7, 4, 4, 1, 4, 1]
    labels = ['neg', 'root', 'advmod', 'mark', 'acl', 'dobj', 'punct']
    cpos = ['ADV', 'VERB', 'ADV', 'ADP', 'VERB', 'NOUN', 'PUNCT']

    tree = dep2etree(words, cpos, cpos, heads, labels)

    trees = mark_transform.apply(tree)

    expected_res = {(tuple(heads), 0),
                    ((1, 7, 3, 1, 3, 4, 1), 1)}
    
    assert is_projective(etree2dep(tree.getroot()))
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.mark
def test_mark_simple():

    transform = MarkTransform(ignore_error=False)
    
    words = ['Difficile', 'de', 'trouver', 'un', 'tel', 'magasin', 'ailleurs', '.']
    heads = [8, 2, 0, 5, 5, 2, 2, 0]
    labels = ['root', 'mark', 'acl', 'det', 'det', 'dobj', 'advmod', 'punct']
    cpos = ['ADJ', 'ADP', 'VERB', 'DET', 'DET', 'NOUN', 'ADV', 'PUNCT']

    tree = dep2etree(words, cpos, cpos, heads, labels)
    
    trees = transform.apply(tree)
    
    expected_res = {((8, 0, 1, 5, 5, 2, 2, 0), 1),
                    (tuple(heads), 0)}
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.mark
def test_mark_after():

    words = ['Cette', 'grossesse', 'étant', 'à', 'risque', 'selon', 'son', 'médecin', ',', 'elle', 'démissionne', 'à', 'contrecoeur', 'de', 'ses', 'fonctions', 'ministérielles', ',', 'mais', 'conserve', 'tout', 'de', 'même', 'son', 'siège', 'de', 'députée', 'de', 'Joliette', 'à', "l'", 'Assemblée', 'nationale', '.']
    heads = [1, 2, 10, 4, 2, 7, 7, 2, 10, 10, 34, 12, 10, 15, 15, 12, 15, 10, 10, 10, 19, 20, 20, 24, 19, 26, 24, 28, 26, 31, 31, 19, 31, 10]
    labels = ['det', 'nsubj', 'advcl', 'case', 'nmod', 'case', 'nmod:poss', 'nmod', 'punct', 'nsubj', 'root', 'case', 'nmod', 'case', 'nmod:poss', 'nmod', 'amod', 'punct', 'cc', 'conj', 'mark', 'mwe', 'mwe', 'nmod:poss', 'dobj', 'case', 'nmod', 'case', 'nmod', 'case', 'det', 'nmod', 'amod', 'punct']

    transform = MarkTransform(ignore_error=False)

    tree = dep2etree(words, words, words, heads, labels)
    
    res = transform.apply(tree)

    # XXX we should have a more precise/complete test
    assert is_projective(etree2dep(tree.getroot()))


# ==============
# CaseTransform
# ==============

@pytest.mark.case
def test_ud_en_doc():
    """
    Transform a dependency tree in a Content-Head format into the Standard format
    """
    head_transform = CaseTransform(ignore_error=False)

    words = "the office of the chair".split()
    heads = [1, 5, 4, 4, 1]
    labels = "det root case det nmode".split()

    expected_res = {(tuple(heads), 0),
                    ((1, 5, 1, 4, 2), 1)}

    input_tree = dep2etree(words, words, words, heads, labels)
    trees = head_transform.apply(input_tree)

    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.case
def test_ud_en_doc_no_poss():
    """
    Ensure that we ignore possives in content-head transformations
    """
    
    head_transform = CaseTransform(ignore_error=False)

    words = "the chair 's office".split()
    heads = [1, 3, 1, 4]
    labels = "det nmode case root".split()

    expected_res = {(tuple(heads), 0)}

    input_tree = dep2etree(words, words, words, heads, labels)
    trees = head_transform.apply(input_tree)

    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res
    assert head_transform.n_apply == 0


@pytest.mark.case
def test_head_non_projectif_before():

    words = ['On', 'ne', 'pensait', "qu'", 'à', 'cela', '.']
    heads = [2, 2, 7, 5, 5, 2, 2]
    labels = ['nsubj', 'neg', 'root', 'advmod', 'case', 'nmod', 'punct']
    cpos = ['PRON', 'PART', 'VERB', 'ADV', 'ADP', 'PRON', 'PUNCT']

    transform = CaseTransform(ignore_error=False)

    tree = dep2etree(words, words, words, heads, labels)
    
    trees = transform.apply(tree)

    expected_res = {((2, 2, 7, 4, 2, 4, 2), 1),
                    (tuple(heads), 0)}
    
    assert {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees} == expected_res


@pytest.mark.case
def test_several_transform():

    words = "il faut à boire et à manger".split()
    heads = [1, 7, 3, 1, 3, 6, 4]
    labels = "subj root case dep cc case conj".split()

    input_tree = dep2etree(words, words, words, heads, labels)
    transform = CaseTransform(ignore_error=False)

    trees = transform.apply(input_tree)

    res = {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees}

    expected_res = {((1, 7, 1, 2, 3, 4, 5), 2),
                    ((1, 7, 3, 1, 3, 6, 4), 0),
                    ((1, 7, 3, 1, 3, 4, 5), 1),
                    ((1, 7, 1, 2, 3, 6, 4), 1)}
    
    assert res == expected_res

@pytest.mark.xfail
@pytest.mark.name
def test_two_names():

    words = ["L'", 'éditeur-en-chef', 'est', 'Corey', 'S.', 'Powell', '.']
    heads = [1, 3, 3, 7, 3, 3, 3]
    labels = ['det', 'nsubj', 'cop', 'root', 'name', 'name', 'punct']
    
    input_tree = dep2etree(words, words, words, heads, labels)
    transform = NameNameTransform(ignore_error=False)

    trees = transform.apply(input_tree)

    res = {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees}

    from pprint import pprint
    pprint(res)

    assert False


@pytest.mark.det
def test_det_transform():

    words = ['Mais', ',', 'le', 'SMIC', "n'", 'est', 'pas', 'un', 'outil', 'de', 'référence', '.']
    heads = [8, 8, 3, 8, 8, 8, 8, 8, 12, 10, 8, 8]
    labels = ['cc', 'punct', 'det', 'nsubj', 'neg', 'cop', 'neg', 'det', 'root', 'case', 'nmod', 'punct']

    input_tree = dep2etree(words, words, words, heads, labels)
    transform = DetTransform(ignore_error=False)

    trees = transform.apply(input_tree)

    res = {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees}

    # for t in trees:
    #     print(etree2str(t[0].getroot()))
    #     print("\n")
    
    expected_res = {((8, 8, 3, 8, 8, 8, 8, 8, 12, 10, 8, 8), 0),
                    ((8, 8, 3, 8, 8, 8, 8, 12, 7, 10, 8, 8), 1),
                    ((8, 8, 8, 2, 8, 8, 8, 8, 12, 10, 8, 8), 1),
                    ((8, 8, 8, 2, 8, 8, 8, 12, 7, 10, 8, 8), 2)}

    assert res == expected_res

@pytest.mark.det
def test_det_non_projectif():

    words = ['Ils', 'tiraient', 'à', 'balles', 'réelles', 'sur', 'la', 'foule', '.']
    heads = [1, 9, 3, 1, 3, 7, 7, 1, 1]
    labels = ['nsubj', 'root', 'case', 'nmod', 'amod', 'case', 'det', 'nmod', 'punct']

    input_tree = dep2etree(words, words, words, heads, labels)
    transform = DetTransform(ignore_error=False)

    trees = transform.apply(input_tree)

    res = {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees}

    assert res == {((1, 9, 3, 1, 3, 6, 1, 6, 1), 1),
                   ((1, 9, 3, 1, 3, 7, 7, 1, 1), 0)}


    words = ['La', 'commune', 'est', 'un', 'chef-lieu', 'de', 'canton', '.']
    heads = [1, 4, 4, 4, 8, 6, 4, 4]
    labels = ['det', 'nsubj', 'cop', 'det', 'root', 'case', 'nmod', 'punct']
    input_tree = dep2etree(words, words, words, heads, labels)
    transform = DetTransform(ignore_error=False)

    trees = transform.apply(input_tree)

    res = {(tuple(etree2dep(t[0].getroot())), t[1]) for t in trees}

    for t in trees:
        if t[1] != 2 and t[1] != 0:
            continue
        print(is_projective(t))
        print(etree2str(t[0].getroot()))
        print("\n")

    assert False


def test_bug_det():

    words = ["L'", 'existence', 'de', 'particules', 'supraluminiques', 'a', 'déjà', 'été', 'postulée', 'par', 'des', 'chercheurs', 'tel', 'le', 'physicien', 'Gerald', 'Feinberg', 'en', '1964', '.']
    heads = [1, 8, 3, 1, 3, 8, 8, 8, 20, 11, 11, 8, 11, 14, 12, 14, 15, 18, 8, 8]
    labels = ['det', 'nsubjpass', 'case', 'nmod', 'amod', 'aux', 'advmod', 'auxpass', 'root', 'case', 'det', 'nmod', 'case', 'det', 'nmod', 'appos', 'name', 'case', 'nmod', 'punct']
    
    input_tree = dep2etree(words, words, words, heads, labels)
    transform = DetTransform(ignore_error=False)

    trees = transform.apply(input_tree)
    
    assert False
