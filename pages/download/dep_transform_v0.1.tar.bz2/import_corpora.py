#
#            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
#                    Version 2, December 2004
#
# Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>
#
# Everyone is permitted to copy and distribute verbatim or modified
# copies of this license document, and changing it is allowed as long
# as the name is changed.
#
#            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
#   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
#
#  0. You just DO WHAT THE FUCK YOU WANT TO.

import sys
import json

from collections import Counter
from itertools import cycle, product


def is_projective(heads, is_padded=True):
    """Check whether a dependency tree is projective or not.

    This methods implements the test described in [1].

    [1] Gomez-Ródríguez and Nivre, A Transition-Based Parser for
    2-Planar Dependency Structures, ACL'10

    Parameters:
    -----------
    - heads, a list of ints
             the heads of each words **including padding symbols**
    """
    # remove START symbol
    edges = [(j, i) for i, j in enumerate(heads)]
    if is_padded:
        edges = edges[1:]

    for (i, k), (j, l) in product(edges, repeat=2):

        # XXX when does it happen?
        if i is None or j is None:
            continue

        # non-projectivity condition for partial trees
        if (j == k and (j > i > l or j < i < l)) or (i == l and (i > j > k or i < j < k)):
            return False

        # canonical non-projectivity condition
        if min(i, k) < min(j, l) < max(i, k) < max(j, l):
            return False

    return True

    
def check_projectivity(heads):
    from warnings import warn
    warn("call to a deprecated function: `check_projectivity`")
    return is_projective(heads)


def read_conllx(filehandler, max_sent=None, without_padding=False, keep_ud_tokenization=True):
    assert not isinstance(filehandler, str)

    header = "ID FORM LEMMA CPOS FPOS MORPHO HEAD LABEL X X".split()

    def convert(word):

        mapping = {"-RRB-": ")",
                   "-LRB-": "(",
                   "-RSB-": "]",
                   "-LSB-": "[",
                   "-LCB-": "{",
                   "-RCB-": "}",}

        return mapping[word] if word in mapping else word

    def parse_morpho(txt):
        # "_|pred=y" happens in SPMRL
        if txt == "_" or txt == "_|pred=y":
            return {}

        return dict(t.split("=") for t in txt.split("|") if "=" in t)

    for n_sentence, ex in enumerate(read_tabular_file(filehandler, header, max_sent, keep_ud_tokenization)):
        words = [convert(e["FORM"]) for e in ex]

        labels = [None] + [e["LABEL"] for e in ex] + [None]

        heads = (int(e["HEAD"]) for e in ex)
        heads = [None] + [h if h != 0 else len(ex) + 1 for h in heads] + [None]

        cpos = [e["CPOS"] for e in ex]
        fpos = [e["FPOS"] for e in ex]
        lemma = [e["LEMMA"] for e in ex]
        morpho = [parse_morpho(e["MORPHO"]) for e in ex]

        if without_padding:
            features = {"cpos": cpos,
                        "fpos": fpos,
                        "morpho": morpho,
                        "lemma": lemma}

            yield words, features, [d - 1 for d in heads[1:-1]], labels[1:-1]
        else:
            features = {"cpos": pad_tokens(cpos),
                        "fpos": pad_tokens(fpos),
                        "morpho": pad_tokens(morpho),
                        "lemma": pad_tokens(lemma)}
            
            yield pad_tokens(words), features, heads, labels


def read_tabular_file(filehandler, header, max_sent, keep_ud_tokenization=True):
    """
    Read `max_sent` sentences from a tabular file.

    Generates, for each example:
    - the position of the token in the sentence
    - the tokenized sentence
    - the features associated to each token
    - the gold heads
    - the labels of the dependency tree
    """
    cur_obser = []
    count_sent = 0
    for line in filehandler:
        if line.startswith("#"):
            continue
        line = line.strip().split()

        if not line:
            yield cur_obser
            cur_obser = []
            count_sent += 1

            if max_sent is not None and count_sent >= max_sent:
                return

            continue

        # In Google UD corpus, the original form of the different
        # words is kept as well as the tokenized form. For instance,
        # "c'était" is described by three lines: the first one
        # correspond to the original form ("c'était" with index "X-Y")
        # and the two others to the tokenized form ("c'" and "était"
        # with, resp., indexes "X" and "Y"). As all annotations refers
        # to the tokenized form, we keep it and discard the original
        # form.
        #
        # Note that, in Google tokenization, some contractions are
        # also split. For instance, in French, "du" is tokenized in
        # "de le" and, in German, "im" is tokenized in "in dem"

        if keep_ud_tokenization:
            if "-" not in line[0]:
                cur_obser.append(dict(zip(header, line)))
            else:
                read_tabular_file.found_hyphen = True
        else:
            if "-" in line[0]:
                assert line[0].count("-") == 1

                line1 = dict(zip(header, next(filehandler).split()))
                line2 = dict(zip(header, next(filehandler).split()))

                # XXX does it make sens to always consider the dependency of the first word
                # assert line1["HEAD"] == line2["HEAD"]

                d = dict(zip(header, line))
                line1["FORM"] = d["FORM"]
                line1["CPOS"] = line1["CPOS"] + "+" + line2["CPOS"]
                
                cur_obser.append(line1)
            else:
                cur_obser.append(dict(zip(header, line)))
                
    if len(cur_obser) != 0:
        yield cur_obser


def pad_tokens(tokens):
    tokens.insert(0, '<start>')
    tokens.append('ROOT')
    return tokens


def import_corpus(input_file, output_file, dump_nonprojective, remove_nonprojective, punctuation):

    import frogress
    
    read_tabular_file.found_hyphen = False
    
    corpus = []
    non_projective = []
    n_words = 0
    n_punctuations = 0
    root_error = 0
    punctuation_labels = Counter()

    data = read_conllx(input_file)
    for count, _ in enumerate(frogress.bar(cycle([None]))):

        try:
            words, features, heads, labels = next(data)
        except StopIteration:
            break
            
        # discard all sentences with more than one root
        if sum(1 for h in heads if h == len(words) - 1) != 1:
            root_error += 1
            continue

        # discard all non-projective sentences
        if not is_projective(heads):
            non_projective.append(count)
            if remove_nonprojective:
                continue

        # ensure that punctuation is correctly labeled
        #
        # we only consider ‘simple’ punctuations that must/should be
        # non ambiguous
        labels = [l if l != punctuation else "punct" for l in labels]

        if not all(l == "punct" for w, l in zip(words, labels) if w in ".,;"):
            n_punctuations += 1
            punctuation_labels.update(l for w, l in zip(words, labels) if w in ".,;" and l != "punct")

        corpus.append((words, features, heads, labels))
        n_words += len(words)

    print("\nserializing {:,} sentences".format(len(corpus)))
    json.dump(corpus, output_file)

    if dump_nonprojective is not None:
        json.dump(non_projective, dump_nonprojective)

    return {
        "#sentences": len(corpus),
        "#non projective sentences": len(non_projective),
        "#words": n_words,
        "#error on punctuation": n_punctuations,
        "punctuation labels": punctuation_labels,
        "#root error": root_error,
        "morpho": any(any(c[1]["morpho"][1:-1]) for c in corpus),
        "advanced_tokenization": read_tabular_file.found_hyphen
    }


if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser()

    parser.add_argument("--input", required=True, type=argparse.FileType("rt"))
    parser.add_argument("--output", required=True, type=argparse.FileType("wt"))
    parser.add_argument("--remove_nonprojective", action="store_true")
    parser.add_argument("--dump_nonprojective", type=argparse.FileType("wt"), default=None)
    parser.add_argument("--punctuation", default="punct")

    args = parser.parse_args()

    if args.dump_nonprojective is not None and args.remove_nonprojective:
        print("--dump_non_projective and --remove_nonprojective can not be used at the same time")
        sys.exit(1)

    r = import_corpus(args.input,
                      args.output,
                      args.dump_nonprojective,
                      args.remove_nonprojective,
                      args.punctuation)
    from pprint import pprint
    pprint(r)
    
